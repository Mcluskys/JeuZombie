# Zombie Memory — version Web / smartphone

Cette version a été adaptée pour **Pygbag** : elle peut tourner dans un navigateur sur PC, Android et iPhone.

## 1. Tester sur ton ordinateur

Installe Python 3 puis, dans un terminal :

```bash
python -m pip install pygbag
cd ZombieMemoryWeb
python -m pygbag main.py
```

Pygbag affiche une adresse locale. Ouvre-la dans ton navigateur.

## 2. Contrôles

- PC : clic de souris.
- Smartphone/tablette : toucher les cartes.
- Pour un meilleur confort, utilise le téléphone en **mode paysage**.

Le son démarre après avoir touché/clické sur **JOUER**, ce qui respecte la règle d'autoplay des navigateurs.

## 3. Générer la version Web

Dans le dossier du jeu :

```bash
python -m pygbag --build main.py
```

Pygbag crée normalement un dossier de build contenant la version web à publier.

## 4. Hébergement gratuit avec GitHub Pages

Une méthode simple consiste à créer un dépôt GitHub, y envoyer le contenu web généré par Pygbag, puis activer **Settings > Pages** dans le dépôt.

Selon ta version de Pygbag, la structure exacte du dossier de build peut varier. Vérifie le dossier généré avant de le publier.

## Remarques

- Le fichier principal doit s'appeler `main.py` pour une utilisation simple avec Pygbag.
- Tous les fichiers du dossier `assets/` doivent rester avec le jeu.
- L'image fournie `zombie(3).png` a été renommée en `assets/zombie.png` pour correspondre au code.
- L'interface affiche les 6 actions en **2 rangées de 3**, ce qui est plus facile à utiliser au doigt.
- Les anciennes boucles bloquantes et `pygame.time.delay()` ont été remplacées par une boucle asynchrone compatible navigateur.
